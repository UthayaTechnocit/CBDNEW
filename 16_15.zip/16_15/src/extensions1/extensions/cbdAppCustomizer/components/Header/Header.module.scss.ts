/* tslint:disable */
require("./Header.module.css");
const styles = {
  root: 'root_64c8cefe',
  header: 'header_64c8cefe',
  logo: 'logo_64c8cefe',
  headerMenus: 'headerMenus_64c8cefe',
  menu: 'menu_64c8cefe',
  profile: 'profile_64c8cefe',
  profileCard: 'profileCard_64c8cefe',
  navbar: 'navbar_64c8cefe',
  'search-box': 'search-box_64c8cefe',
  'search-icon-container': 'search-icon-container_64c8cefe'
};

export default styles;
/* tslint:enable */