import { ApplicationCustomizerContext } from "@microsoft/sp-application-base";
import * as React from "react";
import { useState, useEffect } from "react";
import { VscChromeClose } from "react-icons/vsc";
import { spfi, SPFx } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/profiles";
import "../../../../tailwind.css";
import { Container } from "../Container";

interface INotifier {
  context: ApplicationCustomizerContext;
}

export const Notifier: React.FunctionComponent<INotifier> = (props) => {
  const [listItem, setListItem] = useState<any>();
  const [showAlert, setShowAlert] = useState<boolean>(false);
  const sp = spfi().using(SPFx(props.context));
  const timeNow = new Date().toISOString();
  const [customUserPropertyValue, setCustomUserPropertyValue] = useState<any>();

  async function getAlertListLastRecord() {
    const listLastRecord: any = await sp.web.lists
      .getByTitle("CBDAlerts")
      .items.filter(
        `StartDate le datetime'${timeNow}' and EndDate ge datetime'${timeNow}'`
      )
      .orderBy("ID", false)
      .top(1)();
    setListItem(listLastRecord);
  }
  async function getCustomUserProperty() {
    const myproperty = await sp.profiles.myProperties();
    myproperty.UserProfileProperties.forEach(
      (prop: { Key: string | number; Value: any }) => {
        if (prop.Key === "CDBAlertID") {
          setCustomUserPropertyValue(prop.Value);
          console.log("Property value", prop.Value);
        }
      }
    );
  }
  function checkPropertyMatch(listID: string) {
    console.log("List ID", listID, "Property ", customUserPropertyValue);
    if (listID == customUserPropertyValue) {
      setShowAlert(false);
      console.log("checkin the alert false");
    } else {
      setShowAlert(true);
      console.log("checkin the alert true");
    }
  }
  async function updateCustomUserProperty() {
    let loginName = `i:0#.f|membership|${
      props.context!.pageContext.user.loginName
    }`;
    await sp.profiles.setSingleValueProfileProperty(
      loginName,
      "CDBAlertID",
      `${listItem[0]?.ID}`
    );
    setShowAlert(false);
  }
  useEffect(() => {
    getCustomUserProperty();
    getAlertListLastRecord();
  }, []);

  useEffect(() => {
    if (listItem) {
      checkPropertyMatch(listItem[0]?.ID);
    }
  }, [listItem, customUserPropertyValue]);
  return (
    <>
      {listItem && showAlert && (
        <Container
          classname={`w-full h-12 bg-Alert flex items-center justify-center`}
          containerclassname="flex items-center justify-between"
        >
          <div className="flex items-center justify-start gap-3">
            <img
              src="https://1n4s36.sharepoint.com/sites/test/SiteAssets/cbd/header/Alert.png"
              alt=""
              width={20}
              height={20}
            />
            <span className=" text-white font-Menu text-base">
              <b>Alert:</b> {listItem[0]?.Title}
            </span>
          </div>
          <div></div>
          <VscChromeClose
            className="text-white cursor-pointer"
            onClick={() => updateCustomUserProperty()}
          />
        </Container>
      )}
    </>
  );
};
