import { ApplicationCustomizerContext } from "@microsoft/sp-application-base";
import * as React from "react";
import { useEffect, useState } from "react";
import "./../../../../tailwind.css";
interface IFooterMenu {
  Footer: { Title: string; Url: string }[];
  CopyRights: string;
}

export interface IFooter {
  context: ApplicationCustomizerContext;
}

export const Footer: React.FunctionComponent<IFooter> = (props) => {
  const [footerLinks, setFooterLinks] = useState<IFooterMenu>();
  const footerJsonSourceLink =
    "/sites/test/SiteAssets/cbd/Footer/Footer.json";
  const LogoImage =
    "/sites/test/SiteAssets/cbd/Footer/TransparentLogo.png";

  function getMenuBarItems(): void {
    fetch(footerJsonSourceLink)
      .then((response) => response.json())
      .then((data) => {
        // Here you can work with your menu data
        setFooterLinks(data);
      })
      .catch((error) => {
        console.error("Error fetching the menu data:", error);
      });
  }
  useEffect(() => {
    getMenuBarItems();
  }, []);
  return (
    <div
      className={`w-full h-fit bg-[#353535] flex items-center justify-center`}
    >
      {footerLinks && (
        <div
          className={`sm:container grid grid-flow-row text-[#FFFFFF] items-center gap-y-6 px-4 py-4 lg:grid-flow-col`}
        >
          <div className="order-2 lg:order-1 grid grid-flow-row gap-y-4 items-center lg:grid-flow-col">
            <img src={LogoImage} alt="logo" className="" />
            <span className="col-span-5">{footerLinks?.CopyRights}</span>
          </div>
          <ul className="order-1 grid grid-flow-row items-center gap-y-3 pl-0 lg:order-2 lg:grid-flow-col">
            {footerLinks?.Footer?.map((item, index: number) => {
              return (
                <li
                  className="hover:font-bold hover:text-white list-none"
                  key={index}
                >
                  <a
                    href={item?.Url}
                    className="no-underline text-[#FFFFFF] hover:font-bold hover:text-white "
                  >
                    {item?.Title}
                  </a>
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </div>
  );
};
