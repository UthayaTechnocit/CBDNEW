/* tslint:disable */
require("./Footer.module.css");
const styles = {
  footer: 'footer_a195ea27',
  'footer-section-3': 'footer-section-3_a195ea27',
  'footer-section-1': 'footer-section-1_a195ea27',
  'footer-section-2': 'footer-section-2_a195ea27'
};

export default styles;
/* tslint:enable */