import { ApplicationCustomizerContext } from "@microsoft/sp-application-base";
import * as React from "react";
import { useState, useEffect } from "react";
import { VscChromeClose } from "react-icons/vsc";
import { spfi, SPFx } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/profiles";

import "../../../../tailwind.css";
import { Container } from "../Container";

interface INotifier {
  context: ApplicationCustomizerContext;
}

export const Notifier: React.FunctionComponent<INotifier> = (props) => {
  const [listItem, setListItem] = useState<any>();
  const [showAlert, setShowAlert] = useState<boolean>(false);
  // const [customUserPropertyValue, setCustomUserPropertyValue] =useState<string>();
  const sp = spfi().using(SPFx(props.context));
  const timeNow = new Date().toISOString();

  async function getAlertListLastRecord() {
    const listLastRecord: any = await sp.web.lists
      .getByTitle("CBDAlerts")
      .items.filter(
        `StartDate le datetime'${timeNow}' and EndDate ge datetime'${timeNow}'`
      )
      .orderBy("ID", false)
      .top(1)();
    setListItem(listLastRecord);
    return listLastRecord;
  }
  async function getCustomUserProperty() {
    const myproperty = await sp.profiles.myProperties();
    const index = myproperty.UserProfileProperties.findIndex(
      (j: any) => j?.Key === "CDBAlertID"
    );
    // setCustomUserPropertyValue(myproperty.UserProfileProperties[index]?.Value);
    return myproperty.UserProfileProperties[index]?.Value;
  }
  async function checkPropertyMatch() {
    // console.log("userprops", listID, customUserPropertyValue);
    try {
      const result1 = getCustomUserProperty();
      const result2 = getAlertListLastRecord();
      const [data1, data2] = await Promise.all([result1, result2]);
      console.log("promis", data1, data2);

      if (data1 == data2?.ID) {
        setShowAlert(false);
      } else {
        setShowAlert(true);
      }
    } catch (error) {
      console.log("error in alert check", error);
    }
  }
  async function updateCustomUserProperty() {
    let loginName = `i:0#.f|membership|${
      props.context!.pageContext.user.loginName
    }`;
    await sp.profiles.setSingleValueProfileProperty(
      loginName,
      "CDBAlertID",
      `${listItem[0]?.ID}`
    );
    setShowAlert(false);
  }

  useEffect(() => {
    checkPropertyMatch();
  }, []);
  // useEffect(() => {
  //   if (listItem !== undefined) {
  //     checkPropertyMatch(listItem[0]?.ID);
  //   }
  // }, [listItem, customUserPropertyValue]);
  return (
    <>
      {showAlert && (
        <Container
          classname={`w-full h-12 bg-Alert  items-center justify-center ${
            showAlert ? "flex" : "hidden"
          }`}
          containerclassname="flex items-center justify-between"
        >
          <div className="flex items-center justify-start gap-3">
            <img
              src="https://1n4s36.sharepoint.com/sites/test/SiteAssets/cbd/header/Alert.png"
              alt=""
              width={20}
              height={20}
            />
            <span className=" text-white font-Menu text-base">
              <b>Alert:</b> {listItem[0]?.Title}
            </span>
          </div>
          <div></div>
          <VscChromeClose
            className="text-white cursor-pointer"
            onClick={() => updateCustomUserProperty()}
          />
        </Container>
      )}
    </>
  );
};
