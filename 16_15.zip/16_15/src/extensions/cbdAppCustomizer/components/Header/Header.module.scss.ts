/* tslint:disable */
require("./Header.module.css");
const styles = {
  profile: 'profile_e850a105',
  profileCard: 'profileCard_e850a105',
  notificationGroup: 'notificationGroup_e850a105',
  noticationBar: 'noticationBar_e850a105',
  mainMenu: 'mainMenu_e850a105',
  subMenu1: 'subMenu1_e850a105',
  subMenu2: 'subMenu2_e850a105'
};

export default styles;
/* tslint:enable */