import { ApplicationCustomizerContext } from "@microsoft/sp-application-base";
import * as React from "react";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/profiles";
import "./../../../../tailwind.css";
import "preline/preline";
export interface IHeader {
    context: ApplicationCustomizerContext;
}
export interface IMenuItem {
    title: string;
    url?: string;
    submenus?: IMenuItem[];
}
export declare const Header: React.FunctionComponent<IHeader>;
//# sourceMappingURL=Header.d.ts.map