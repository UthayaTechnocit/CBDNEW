declare const styles: {
    profile: string;
    profileCard: string;
    notificationGroup: string;
    noticationBar: string;
    mainMenu: string;
    subMenu1: string;
    subMenu2: string;
};
export default styles;
//# sourceMappingURL=Header.module.scss.d.ts.map