import { ApplicationCustomizerContext } from "@microsoft/sp-application-base";
import * as React from "react";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/profiles";
import "../../../../tailwind.css";
interface INotifier {
    context: ApplicationCustomizerContext;
}
export declare const Notifier: React.FunctionComponent<INotifier>;
export {};
//# sourceMappingURL=Notifier.d.ts.map