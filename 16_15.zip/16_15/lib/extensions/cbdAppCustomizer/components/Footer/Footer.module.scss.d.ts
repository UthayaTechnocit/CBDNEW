declare const styles: {
    footer: string;
    'footer-section-3': string;
    'footer-section-1': string;
    'footer-section-2': string;
};
export default styles;
//# sourceMappingURL=Footer.module.scss.d.ts.map