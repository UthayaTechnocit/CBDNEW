import { ApplicationCustomizerContext } from "@microsoft/sp-application-base";
import * as React from "react";
import "./../../../../tailwind.css";
export interface IFooter {
    context: ApplicationCustomizerContext;
}
export declare const Footer: React.FunctionComponent<IFooter>;
//# sourceMappingURL=Footer.d.ts.map