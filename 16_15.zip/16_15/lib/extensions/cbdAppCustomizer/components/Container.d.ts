import * as React from "react";
import { ReactNode } from "react";
import "./../../../tailwind.css";
interface IContainer {
    classname?: string;
    containerclassname?: string;
    children: ReactNode;
}
export declare const Container: React.FunctionComponent<IContainer>;
export {};
//# sourceMappingURL=Container.d.ts.map