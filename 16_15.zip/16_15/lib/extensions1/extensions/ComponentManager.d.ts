import { ApplicationCustomizerContext } from "@microsoft/sp-application-base";
export default class ComponentManager {
    static renderHeader(context: ApplicationCustomizerContext, element: HTMLElement): void;
    static renderFooter(context: ApplicationCustomizerContext, element: HTMLElement): void;
    static renderNotifier(context: ApplicationCustomizerContext, element: HTMLElement): void;
    static _dispose(element: HTMLElement): void;
}
//# sourceMappingURL=ComponentManager.d.ts.map