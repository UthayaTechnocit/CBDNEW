import * as React from "react";
import { IMenuItem } from "./Header";
export interface IPageProps {
    submenus: IMenuItem[];
    isOpen: boolean;
}
declare const SubMenu: React.FunctionComponent<IPageProps>;
export default SubMenu;
//# sourceMappingURL=SubMenu.d.ts.map