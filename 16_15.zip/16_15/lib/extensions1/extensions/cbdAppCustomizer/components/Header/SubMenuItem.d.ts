import * as React from "react";
import { IMenuItem } from "./Header";
export interface IPageProps {
    submenus: IMenuItem[];
    isOpen: boolean;
}
declare const SubMenuItems: React.FunctionComponent<IPageProps>;
export default SubMenuItems;
//# sourceMappingURL=SubMenuItem.d.ts.map