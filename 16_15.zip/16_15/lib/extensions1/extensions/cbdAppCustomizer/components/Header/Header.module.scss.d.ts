declare const styles: {
    root: string;
    header: string;
    logo: string;
    headerMenus: string;
    menu: string;
    profile: string;
    profileCard: string;
    navbar: string;
    'search-box': string;
    'search-icon-container': string;
};
export default styles;
//# sourceMappingURL=Header.module.scss.d.ts.map