import { BaseApplicationCustomizer } from "@microsoft/sp-application-base";
export interface ICbdAppCustomizerApplicationCustomizerProperties {
    cssurl: string;
}
export default class CbdAppCustomizerApplicationCustomizer extends BaseApplicationCustomizer<ICbdAppCustomizerApplicationCustomizerProperties> {
    private header;
    private footer;
    private notifier;
    onInit(): Promise<void>;
    private bootstrap;
    private _onDispose;
}
//# sourceMappingURL=CbdAppCustomizerApplicationCustomizer.d.ts.map